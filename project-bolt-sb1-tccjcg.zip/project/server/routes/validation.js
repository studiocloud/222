import express from 'express';
import multer from 'multer';
import { parse } from 'csv-parse';
import { createReadStream, unlinkSync } from 'fs';
import { validateEmail } from '../validators/email.js';

const router = express.Router();

const upload = multer({ 
  dest: 'uploads/',
  limits: { 
    fileSize: 50 * 1024 * 1024 // 50MB
  },
  fileFilter: (req, file, cb) => {
    if (!file.originalname.toLowerCase().endsWith('.csv')) {
      cb(new Error('Only CSV files are allowed'));
      return;
    }
    cb(null, true);
  }
});

// Single email validation endpoint
router.post('/validate', async (req, res) => {
  try {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({
        valid: false,
        reason: 'Email is required'
      });
    }

    const result = await validateEmail(email);
    return res.json(result);
  } catch (error) {
    console.error('Validation error:', error);
    return res.status(500).json({
      valid: false,
      reason: process.env.NODE_ENV === 'production' 
        ? 'Server error occurred' 
        : error.message
    });
  }
});

// Optimized bulk validation endpoint
router.post('/validate/bulk', upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ 
      type: 'error',
      error: 'CSV file is required' 
    });
  }

  // Set headers for streaming response
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Transfer-Encoding', 'chunked');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('X-Accel-Buffering', 'no');

  // Extended timeouts
  req.setTimeout(3600000); // 1 hour
  res.setTimeout(3600000); // 1 hour

  let processedCount = 0;
  let totalRecords = 0;
  const results = [];
  let cleanup = true;

  try {
    // First pass: count total records
    const countParser = parse({
      columns: true,
      skip_empty_lines: true,
      trim: true
    });

    await new Promise((resolve, reject) => {
      createReadStream(req.file.path)
        .pipe(countParser)
        .on('data', () => { totalRecords++; })
        .on('error', reject)
        .on('end', resolve);
    });

    if (totalRecords === 0) {
      throw new Error('CSV file is empty');
    }

    // Second pass: process records
    const parser = parse({
      columns: true,
      skip_empty_lines: true,
      trim: true
    });

    const stream = createReadStream(req.file.path);
    
    await new Promise((resolve, reject) => {
      let lastProgressUpdate = Date.now();
      const PROGRESS_INTERVAL = 1000; // Update progress every second

      stream
        .pipe(parser)
        .on('data', async (record) => {
          parser.pause(); // Pause parsing while processing the record

          try {
            const email = record.email || record.Email || record.EMAIL;
            let validationResult;

            if (!email) {
              validationResult = {
                email: '',
                validation_result: 'Invalid',
                validation_reason: 'No email address found',
                mx_check: false,
                dns_check: false,
                spf_check: false,
                mailbox_check: false,
                smtp_check: false
              };
            } else {
              const result = await validateEmail(email);
              validationResult = {
                email,
                validation_result: result.valid ? 'Valid' : 'Invalid',
                validation_reason: result.reason || 'Unknown validation status',
                mx_check: result.checks?.mx || false,
                dns_check: result.checks?.dns || false,
                spf_check: result.checks?.spf || false,
                mailbox_check: result.checks?.mailbox || false,
                smtp_check: result.checks?.smtp || false
              };
            }

            results.push(validationResult);
            processedCount++;

            // Send progress updates at intervals
            const now = Date.now();
            if (now - lastProgressUpdate >= PROGRESS_INTERVAL) {
              const progress = (processedCount / totalRecords) * 100;
              res.write(JSON.stringify({
                type: 'progress',
                progress,
                processing: true,
                results: [validationResult]
              }) + '\n');
              lastProgressUpdate = now;
            }

            // Add a small delay between validations to prevent overwhelming the server
            await new Promise(resolve => setTimeout(resolve, 100));
            parser.resume(); // Resume parsing
          } catch (error) {
            console.error('Record processing error:', error);
            processedCount++;
            parser.resume(); // Resume parsing even if there's an error
          }
        })
        .on('error', (error) => {
          console.error('Parser error:', error);
          cleanup = false;
          reject(error);
        })
        .on('end', () => {
          // Send final results
          res.write(JSON.stringify({
            type: 'complete',
            processing: false,
            totalProcessed: processedCount,
            results
          }) + '\n');
          resolve();
        });

      // Handle client disconnect
      req.on('close', () => {
        cleanup = true;
        stream.destroy();
        parser.end();
        resolve();
      });
    });

    res.end();
  } catch (error) {
    console.error('Bulk validation error:', error);
    if (!res.headersSent) {
      res.status(500);
    }
    res.write(JSON.stringify({
      type: 'error',
      error: process.env.NODE_ENV === 'production'
        ? 'Failed to process CSV file'
        : error.message
    }) + '\n');
    res.end();
  } finally {
    // Cleanup uploaded file
    if (cleanup && req.file?.path) {
      try {
        unlinkSync(req.file.path);
      } catch (error) {
        console.error('Failed to cleanup uploaded file:', error);
      }
    }
  }
});

export default router;